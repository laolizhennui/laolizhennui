import requests
from os import mkdir
from copy import copy
from time import time
from urllib.request import quote, unquote
from os import listdir
from io import BytesIO
from array import array
from zipfile import ZipFile
from re import findall, sub
from base64 import b64decode
from Crypto.Cipher import AES
from DownloadKit import DownloadKit
from os.path import join as path_join, isfile, isdir
from json import loads as json_loads, dump as json_dump

output = r"D:\VideoTemp\ccw_output"


class Project:

    def __init__(self, project_id: str) -> None:
        self._id: str = project_id
        self.key: str = None
        self.data_url: str = None
        self.data: bytes = None
        self.json: dict = None
        self.json_text: str = None
        self.resource_list: list = None
        self.title: str = None
        self.zip_head = array("B", [80, 75, 3, 4, 10, 0, 0, 0])
        self.png_head = array("B", [55, 122, 188, 175, 9, 5, 2, 7])

    def download(self):
        print("开始下载")
        self.get_project_detail()
        self.get_project_data()
        self.get_project_json()
        self.get_project_resource_list()
        self.download_resources()
        self.save_json()
        self.save_detail()
        self.add_zip()

    def get_project_detail(self):
        url = "https://community-web.ccw.site/creation/detail"
        post_data = {"oid": self._id, "accessKey": ""}
        resp_json = requests.post(url, json=post_data).json()
        if resp_json["status"] == 200:
            self.title: str = resp_json["body"]["title"]
            self.data_url: str = resp_json["body"]["creationRelease"]["projectLink"]
            self.key: str = self.data_url.split("/")[-1].split(".")[0]
            self.detail: str = resp_json["body"]

    def get_project_data(self):
        resp = requests.get(self.data_url)
        self.data: bytes = resp.content

    def reverse_string(self, e):
        t = len(e) - 1
        n = str(t)[-1]
        r = e[t]
        return e[: int(n)] + r + e[int(n) + 1 : t]

    def get_project_json(self):
        file_head = array("B", self.data[:8])

        if file_head == self.png_head:  # 如果文件有PNG头, What???
            print("实行换头手术")
            zip_data = self.zip_head + self.data[8:]
        elif file_head != self.zip_head:
            print("加密")
            self.data = self.decrypt(b64decode(self.data))
            zip_data = array("B", map(int, self.data.split(b",")))
        else:
            zip_data = copy(self.data)

        zip_archive = ZipFile(BytesIO(zip_data))  # 打开压缩包
        json_data = zip_archive.read("Project.json".lower())  # 提取出Project.json文件
        self.json_text = json_data.decode()
        if self.json_text.startswith("{"):
            self.json: dict = json_loads(self.json_text)  # 提取Json
        else:
            self.json_text = b64decode(self.reverse_string(json_data.decode())).decode()
            self.json_text = unquote(self.json_text)
            self.json: dict = json_loads(self.json_text)

        print("已获取作品Json")
        zip_archive.close()  # 关闭压缩包

    def get_project_resource_list(self):
        self.resource_list = findall("[0-9a-z]{32}\.[\w]{2,4}", self.json_text)
        print("作品资源数量:", len(self.resource_list))

    def download_resources(self):
        self.path_title = self.filter_basename(self.title)
        self.output = path_join(output, self.path_title)
        if not isdir(self.output):
            mkdir(self.output)
        kit = DownloadKit(roads=15)
        for resource_id in self.resource_list:
            resource_url = "https://m.ccw.site/user_projects_assets/" + resource_id
            kit.add(resource_url, self.output)
        kit.wait(show=True, timeout=10)

    def save_json(self):
        print("正在保存作品Json")
        with open(path_join(self.output, "project.json"), "w+", encoding="utf-8") as f:
            json_dump(self.json, f, ensure_ascii=False, indent=4)

    def save_detail(self):
        print("正在保存作品Detail")
        with open(path_join(self.output, "detail.json"), "w+", encoding="utf-8") as f:
            json_dump(self.detail, f, ensure_ascii=False, indent=4)

    def add_zip(self):
        zip = ZipFile(path_join(output, self.path_title + ".sb3"), "w")
        for name in listdir(self.output):
            fp = path_join(self.output, name)
            if isfile(fp):
                print("写入Zip:", name)
                with open(fp, "rb") as f:
                    zip.writestr(name, f.read())
        zip.close()

    def filter_basename(self, basename: str):
        return sub(r"|[\\/:*?\"<>|]+", "", basename.strip())

    def decrypt(self, data: bytes) -> str:
        key = b64decode("KzdnFCBRvq3" + self.key + "=")
        iv = key[:16]
        aes_obj = AES.new(key, AES.MODE_CBC, iv)
        return aes_obj.decrypt(data)


project = Project("62fddb7d19d74b06a84b2334")
project.download()
